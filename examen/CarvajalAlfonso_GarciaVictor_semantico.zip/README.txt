Para compilar y ejecutar, comando: sh alfa.sh file_entrada file_salida
        
        !! METER LOS NOMBRES SIN EXTENSIONES !!

        file_entrada: nombre del fichero file_entrada.alf
        file_salida: nombre del fichero file_salida.asm

Para generar el ejecutable, comando: make all
