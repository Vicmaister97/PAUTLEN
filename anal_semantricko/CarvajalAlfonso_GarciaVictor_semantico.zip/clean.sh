rm lex.yy.c
rm y.tab.c
rm ex1
rm pruebaSemantico
rm y.output
rm misalida_sem_1.o
rm ex*